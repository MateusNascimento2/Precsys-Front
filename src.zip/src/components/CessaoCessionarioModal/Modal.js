import React, { useState, useRef, useEffect } from 'react'
import LoadingSpinner from '../LoadingSpinner/LoadingSpinner'
import { ModalTab } from './ModalTab'
import { FormAdicionarCessionario } from './FormAdicionarCessionario';
import { FormAdicionarCessao } from './FormAdicionarCessao';
import useAxiosPrivate from '../../hooks/useAxiosPrivate';


export function Modal({ onAddCessionario, onDeleteCessionarioForm, handleCessionarioInputChange, cessionariosQtd, formCessionario, setFormDataCessionario, handleSubmit, status, handleNomeTab, formDataCessao, handleCessaoInputChange }) {
  const axiosPrivate = useAxiosPrivate();
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [isTabSelected, setIsTabSelected] = useState(null);
  const [nomeTab, setNomeTab] = useState('');
  const modalElement = useRef();
  const statusRef = useRef(status); // Ref para armazenar o status
  const [orcamentos, setOrcamentos] = useState([]);
  const [anosOrcamento, setAnosOrcamento] = useState([]);
  const [empresas, setEmpresas] = useState([]);
  const [teles, setTeles] = useState([]);
  const [juridico, setJuridico] = useState([]);
  const [varas, setVaras] = useState([]);
  const [natureza, setNatureza] = useState([]);
  const [escrevente, setEscrevente] = useState([]);
  const [users, setUsers] = useState([]);


  useEffect(() => {
    let isMounted = true; // ✅ Flag para verificar se o componente está montado

    const fetchData = async (ApiRoute, setter) => {
      try {
        const { data } = await axiosPrivate.get(ApiRoute);
        if (isMounted) {  // ✅ Só atualiza o estado se o componente ainda estiver montado
          setter(data);
        }
      } catch (e) {
        console.log(e);
      }
    };


    fetchData('/orcamentos', setOrcamentos);
    fetchData('/empresas', setEmpresas);
    fetchData('/nomeTele', setTeles);
    fetchData('/juridicos', setJuridico);
    fetchData('/vara', setVaras);
    fetchData('/natureza', setNatureza);
    fetchData('/escreventes', setEscrevente);
    fetchData('/users', setUsers);





    return () => {
      isMounted = false; // ✅ Cleanup: evita atualização após desmontar
    };
  }, []);


  // Atualiza a referência do status sempre que ele mudar
  useEffect(() => {
    statusRef.current = status;
  }, [status]);


  useEffect(() => {
    const handler = (event) => {
      if (!modalElement.current) {
        return;
      }

      // Se status for 'sending', não fechar o modal ao clicar fora
      if (statusRef.current === 'sending') return;

      if (!modalElement.current.contains(event.target)) {
        setIsModalOpen(false);
      }

    }

    document.addEventListener("click", handler, true);

    return () => {
      document.removeEventListener("click", handler);
    }
  }, []);

  const handleShowForm = (index, action) => {
    if (action === "selecionar") {
      setIsTabSelected(index);
    } else if (action === "excluir") {
      // Se a aba excluída for a aba ativa
      if (isTabSelected === index) {
        if (index > 0) {
          setIsTabSelected(index - 1); // Seleciona a aba anterior
        } else {
          setIsTabSelected(null); // Se era a única aba, volta para null
        }
      } else if (isTabSelected > index) {
        // Se a aba removida está antes da aba ativa, mantém a mesma aba
        setIsTabSelected((prev) => prev - 1);
      }
    } else {
      setIsTabSelected(index)
    }
  };

  const handleModalShow = () => {
    setIsModalOpen(prevState => !prevState)
  }

  const handleAnoOrcamento = async (id) => {

    if (id) {
      console.log(id)
      const { data } = await axiosPrivate.post('OrcamentosComAnos', {
        id
      })
      setAnosOrcamento(data);
      console.log(data)
    } else {
      setAnosOrcamento([]);
    }

  }

  return (
    !isModalOpen ? (
      <>
        <button onClick={() => setIsModalOpen(true)}>Abrir Modal</button>
      </>

    ) : (
      <div className='relative w-[100vw] h-[100vh] bg-black bg-opacity-40'>
        <div ref={modalElement} className='bg-white w-[85%] h-[80%] top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] rounded shadow-sm absolute'>

          <ModalTab status={status} nomeTab={nomeTab} cessionariosQtd={cessionariosQtd} onAddCessionario={onAddCessionario} onDeleteCessionarioForm={onDeleteCessionarioForm} isTabSelected={isTabSelected} handleShowForm={handleShowForm} handleModalShow={handleModalShow} />

          {status === 'sending' ? (
            <div className='p-4 overflow-y-auto h-[calc(100%-50px)] lg:flex lg:flex-col lg:justify-between'>

              <div className='w-full h-full absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] bg-black bg-opacity-20 flex justify-center items-center'>
                <div className='w-10 h-10'>
                  <LoadingSpinner />
                </div>
              </div>

              <div>
                <form>
                  <div>
                    {/* Mantém os formulários montados, mas esconde um deles dinamicamente */}
                    <div style={{ display: isTabSelected !== null ? "none" : "block" }}>
                      <FormAdicionarCessao
                        formDataCessao={formDataCessao}
                        handleCessaoInputChange={handleCessaoInputChange}
                        orcamentos={orcamentos}
                        anosOrcamento={anosOrcamento}
                        handleAnoOrcamento={handleAnoOrcamento}
                        empresas={empresas}
                        teles={teles}
                        juridico={juridico}
                        varas={varas}
                        natureza={natureza}
                        escrevente={escrevente}
                      />
                    </div>

                    {cessionariosQtd.map((cessionario, index) => (
                      <div key={cessionario.id} style={{ display: isTabSelected === index ? "block" : "none" }}>
                        <FormAdicionarCessionario
                          cessionario={cessionario}
                          formCessionario={formCessionario}
                          setFormDataCessionario={setFormDataCessionario}
                          index={index}
                          isTabSelected={isTabSelected}
                          handleSubmit={handleSubmit}
                          handleCessionarioInputChange={handleCessionarioInputChange}
                          handleNomeTab={handleNomeTab}
                          users={users}
                        />
                      </div>
                    ))}
                  </div>

                </form>
              </div>

              <div>
                <button className='border rounded py-1 px-4 float-right mt-4 lg:mt-0 hover:bg-neutral-200' onClick={handleSubmit}>Salvar</button>
              </div>


            </div>) :
            <div className='p-4 overflow-y-auto h-[calc(100%-50px)] lg:flex lg:flex-col lg:justify-between'>
              <div>
                <form>
                  <div>
                    {/* Mantém os formulários montados, mas esconde um deles dinamicamente */}
                    <div style={{ display: isTabSelected !== null ? "none" : "block" }}>
                      <FormAdicionarCessao
                        formDataCessao={formDataCessao}
                        handleCessaoInputChange={handleCessaoInputChange}
                        orcamentos={orcamentos}
                        anosOrcamento={anosOrcamento}
                        handleAnoOrcamento={handleAnoOrcamento}
                        empresas={empresas}
                        teles={teles}
                        juridico={juridico}
                        varas={varas}
                        natureza={natureza}
                        escrevente={escrevente}
                      />
                    </div>

                    {cessionariosQtd.map((cessionario, index) => (
                      <div key={cessionario.id} style={{ display: isTabSelected === index ? "block" : "none" }}>
                        <FormAdicionarCessionario
                          cessionario={cessionario}
                          formCessionario={formCessionario}
                          setFormDataCessionario={setFormDataCessionario}
                          index={index}
                          isTabSelected={isTabSelected}
                          handleSubmit={handleSubmit}
                          handleCessionarioInputChange={handleCessionarioInputChange}
                          handleNomeTab={handleNomeTab}
                          users={users}
                        />
                      </div>
                    ))}
                  </div>

                </form>
              </div>

              <div>
                <button className='border rounded py-1 px-4 float-right mt-4 lg:mt-0 hover:bg-neutral-200' onClick={handleSubmit}>Salvar</button>
              </div>
            </div>
          }

        </div>
      </div>
    )
  )
}