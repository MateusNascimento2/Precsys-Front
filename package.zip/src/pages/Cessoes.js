import React from 'react'

export default function Cessoes() {
  return (
    <div>Cessoes</div>
  )
}
